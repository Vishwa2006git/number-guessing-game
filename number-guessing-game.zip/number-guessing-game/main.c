// main.c content provided earlier
